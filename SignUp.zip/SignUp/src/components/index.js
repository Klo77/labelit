export {default as SignUp} from './signUp/SignUp'
