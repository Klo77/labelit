import React from 'react'
import './App.css'
import { SignUp } from './components/index'

const App = () => {
  return (
    <SignUp/>
  )
}

export default App